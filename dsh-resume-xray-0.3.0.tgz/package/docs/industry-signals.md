# 行业信号：热门行业的面试追问

v0.3 增加了 9 个行业画像。它们和通用五类风险、后端信号叠加使用：通用规则负责“这句话有没有证据”，行业画像负责“这个行业还会追问什么”。

> 这些画像是从公开面经、题库和招聘方文章里提炼的**经验性追问维度**，不是任何公司的真实评分表，也没有经过统计验证。规则仍是正则启发式，会误报、会漏报。

## 怎么启用

`resume_xray_scan` 新增可选参数 `industry`：

```text
resume_xray_scan(resumeText, targetRole?, industry?)
```

- 显式传 `industry` 时，先按行业匹配画像；
- 没传时，从 `targetRole` 里推断（例如“大模型算法”“芯片验证”“游戏客户端”）；
- 最多同时启用 2 个画像，避免报告失焦；
- 行业信号会写入每条风险的 `signals[]`，例如 `industry:ai:标签无规模/评测`；
- 摘要会追加“行业证据提示”，列出简历里没覆盖的维度。

## 9 个画像

| 行业 | 面试官最爱追问 | 触发标签（示例） | 需要的证据（示例） |
|---|---|---|---|
| **AI/大模型** | 模型规模、数据量、评测基线、推理成本、幻觉兜底 | 大模型、RAG、Agent、微调、SFT/RLHF、LoRA | 参数量、数据条数、GPU/卡时、评测集、baseline、消融、延迟/成本 |
| **智能驾驶/新能源** | 场景覆盖、里程、mAP/接管率、实时性、功能安全、量产 | 自动驾驶、感知、规控、域控、BEV、SLAM、AUTOSAR | 里程/场景数、mAP、接管率、TOPS、ms、ISO 26262/ASIL、HIL/SIL |
| **半导体/芯片** | 工艺节点、模块规模、覆盖率、PPA、流片/回片、良率 | 芯片、SoC、验证、UVM、DFT、时序、流片 | nm、门数、覆盖率、WNS/TNS、功耗/面积、回片结果、良率 |
| **机器人/智能制造** | 负载/工作空间、精度、节拍、MTBF、实时安全、量产验收 | 机器人、ROS、SLAM、运动控制、机械臂、AGV/AMR | kg、mm、Hz、ms、节拍、MTBF、客户验收、急停/失效 |
| **金融科技/风控** | 交易量、TPS/延迟、欺诈率/误杀率、合规审计、资金安全、灾备 | 风控、支付、信贷、反欺诈、清结算、核心系统 | 万笔/亿笔、TPS、ms、欺诈率、误杀率、坏账、对账、灾备 |
| **跨境电商/出海** | 市场规模、GMV、转化/复购、CAC/LTV、本地化合规、支付/物流 | 跨境电商、出海、供应链、本地化、Temu/SHEIN | GMV、订单量、转化率、复购、CAC/LTV、关税/合规、支付失败率 |
| **游戏** | DAU/留存、帧率/内存/包体、玩法/数值、上线/外挂/版号 | 游戏、Unity/Unreal、客户端、引擎、玩法、数值 | DAU、次留、fps、ms、MB/GB、上线数据、外挂治理、版号 |
| **数据分析/产品/运营** | 指标口径、A/B 样本/显著性、漏斗/分群、归因/反事实 | 增长、产品经理、数据分析、运营、商业化、A/B | 北极星/过程指标、样本量、置信度、漏斗、留存/复购、ROI |
| **咨询/战略** | 问题拆解、数据来源、方案取舍、客户落地/量化影响 | 咨询、战略、商业分析、尽调、行业研究 | 框架/假设、访谈/样本、数据源、方案对比、降本/增收、市场份额 |

## 这些追问从哪来

| 行业 | 主要来源 | 提炼出的信号 |
|---|---|---|
| AI/大模型 | [llm-master 大模型面经汇总](https://github.com/youngyangyang04/llm-master/blob/main/docs/interview/llm/README.md)、[llm-interview-questions](https://github.com/MisterBooo/llm-interview-questions) | RAG/Agent/微调必考；会追 Chunk、Rerank、幻觉、Token 治理、评测与消融；只写“用了 RAG”不够 |
| 智能驾驶 | [Autonomous-Driving-Cpp 面试八股](https://github.com/Yicen-y/Autonomous-Driving-Cpp/blob/main/interview_questions/README.md) | 感知/规控/控制/SLAM/部署分岗深挖；会追算法对比、传感器融合、时间同步、实时性、故障降级 |
| 半导体/芯片 | [数字 IC 验证面经](https://www.eet-china.com/mp/a353299.html) | 验证环境、覆盖率、scoreboard、寄存器模型、时序/CDC、流片/回片；会追“覆盖率低/高的原因”和印象最深的 bug |
| 机器人 | [VLA-Handbook 题库](https://github.com/sou350121/VLA-Handbook/blob/main/question-bank/README.md)、[Autonomous-Driving-Cpp](https://github.com/Yicen-y/Autonomous-Driving-Cpp/blob/main/interview_questions/README.md) | SLAM/运动控制/感知融合；会追精度、实时性、场景鲁棒性、安全与量产 |
| 金融科技 | [美团金融风控策略面经](https://www.nowcoder.com/feed/main/detail/3d329bf28869485cbdb7054a507a282a) | 业务定义→风险定义→评分卡→策略评估；会追正负样本、欺诈率/误杀率、合规与资金安全 |
| 跨境电商 | [Temu 海外扩张 PM 真题解析](https://sirjohnnymai.com/zh/blog/zh-pingduoduo-pm-strategy-case/) | 低价背后的供应链重构、获客漏斗、CAC/LTV、本地化合规；只会说“投广告/降价”会被追问 |
| 游戏 | [网易雷火游戏客户端面经](https://www.wondercv.com/community/22335.html) | 客户端/引擎/玩法细节；会追 UGUI 源码、Lua 闭包、GC、渲染管线、ECS、性能与上线问题 |
| 数据/产品/运营 | [岗位方向专项题库](https://github.com/lan1177/interview-prep/blob/main/references/role-types.md) | 北极星指标、A/B 样本/显著性、AARRR、用户分层、归因；会追“为什么是这个指标”和反事实 |
| 咨询/战略 | [岗位方向专项题库](https://github.com/lan1177/interview-prep/blob/main/references/role-types.md) | 问题拆解、市场空间、竞争壁垒、方案取舍、客户落地；会追数据来源和量化影响 |

## 规则怎么工作

每条行业画像包含四部分：

1. `buzz`：行业标签，例如“大模型/RAG/微调”“SoC/UVM/流片”。
2. `evidence`：能把标签变成可追问事实的证据，例如参数量、覆盖率、TPS、GMV、样本量。
3. `chain`：四步追问链，按该行业的真实面试路径设计。
4. `coverage`：用于摘要提示的证据维度。

如果一句话命中 `buzz` 但没有命中 `evidence`，就会产生一条行业信号。它不会替代通用 `riskType`：

- 如果通用规则已经报了更根本的问题（数字无口径、职责不清、团队/个人），保留通用类型，把行业信号加进 `signals[]`；
- 如果通用规则只报了“结论无证据/因果缺口”，行业链更具体，就用行业链；
- 如果通用规则没报，行业信号单独成条。

## 没有做的事

- 没有覆盖所有热门行业：生物医药、低空经济、新材料、消费/零售等还没有独立画像。
- 没有判断候选人是否真的做过；只判断“这句话有没有该行业面试官要的证据”。
- 没有声称准确率；行业画像之间可能重叠（例如“SLAM 算法”会同时匹配 AI、自动驾驶、机器人），最多取 2 个。
- 没有把公开面经当成标准答案；它们只用来决定“追问方向”。

## 参考链接

- [llm-master：2026 最全大模型面经汇总](https://github.com/youngyangyang04/llm-master/blob/main/docs/interview/llm/README.md)
- [llm-interview-questions](https://github.com/MisterBooo/llm-interview-questions)
- [Autonomous-Driving-Cpp：自动驾驶面试八股](https://github.com/Yicen-y/Autonomous-Driving-Cpp/blob/main/interview_questions/README.md)
- [数字 IC 验证面经](https://www.eet-china.com/mp/a353299.html)
- [VLA-Handbook：机器人/VLA 题库](https://github.com/sou350121/VLA-Handbook/blob/main/question-bank/README.md)
- [美团金融风控策略面经](https://www.nowcoder.com/feed/main/detail/3d329bf28869485cbdb7054a507a282a)
- [Temu 海外扩张 PM 真题解析](https://sirjohnnymai.com/zh/blog/zh-pingduoduo-pm-strategy-case/)
- [网易雷火游戏客户端面经](https://www.wondercv.com/community/22335.html)
- [岗位方向专项题库（产品/增长/运营/战略）](https://github.com/lan1177/interview-prep/blob/main/references/role-types.md)
