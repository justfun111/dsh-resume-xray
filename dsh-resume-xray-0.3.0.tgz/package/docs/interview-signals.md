# 判断条件从哪来：面试官视角的信号

v0.2 在原来的五类规则上补了一层“面试官会怎么追问”的信号。这里记录公开资料的来源、提炼出的模式，以及它们对应到 `lib/scan.js` 的哪条规则。

> 这些是公开面经、面试指南和招聘方文章的**经验性总结**，不是经过验证的招聘标准，也不代表任何一家公司的真实评分表。规则仍然是启发式正则，会误报、会漏报；它的价值是把“值得追问的句子”找出来，而不是给候选人下结论。
>
> v0.3 的 9 个行业画像（AI、智能驾驶、芯片、机器人、金融科技、跨境电商、游戏、数据/产品、咨询）单独记录在 [industry-signals.md](industry-signals.md)。

## 来源与映射

| 来源 | 提炼出的追问模式 | 落到哪条规则 |
|---|---|---|
| [JavaGuide：后端项目面试怎么讲](https://javaguide.cn/interview-preparation/backend-project-interview-guide.html) | 面试官会确认：你具体负责哪些代码/数据/上下游；技术选型为什么这样选、替代方案和代价；难点要能讲“现象→约束→排查→方案比较→验证”；指标要能说明 QPS/P95/P99、数据量、机器配置；故障要能讲发现、止血、根因、修复、防复发 | `role_inflation`、`metric_context`、`backend_buzz`、`causal_gap`；`backend_buzz` 的四问链 |
| [北森：候选人夸大项目经历怎么办](https://www.beisen.com/res/3561.html) | 夸大分三种：搭便车（团队项目挂名）、放大（一个模块说成主导整个系统）、虚构（听过/了解说成做过）；共同点是“宏观叙事流畅、微观细节缺失”；追问沿参数、版本、踩坑、协作摩擦下探三层 | `role_inflation`、`team_vs_individual`、`mastery`；追问链的“团队/个人边界”“现场举例” |
| [WPS：AI 写简历准吗](https://www.wps.cn/article/ai-write-resume-accuracy-check-edit-guide.html) | AI 最容易编造：量化数字、职位/职责升级（参与→主导、协助→负责）、没做过的项目成果；检查法是数字溯源、职责降级重读、面试回溯测试（追问细节答不上来就删） | `strong_claim`、`role_inflation`、`mastery`；`why` 里的“没有数字/没有边界” |
| [STAR 面试话术与模拟面试](https://github.com/bcefghj/learn-nanobot/blob/main/docs/16-star-interview-script/README.md) | STAR 的 Action 应占约 50%、Result 约 20%；“简历写了精通 xxx，面试官会往死里问”；每个项目准备 5 个可能追问；面试回溯测试 | `mastery`、`causal_gap`；`mastery` 的四问链 |
| [阿里云：面试官问项目有哪些难点](https://developer.aliyun.com/article/1576468) | 高频难点：高并发（缓存/限流降级/异步/分库分表）、缓存一致性、消息丢失/积压、间歇性 OOM、慢 SQL/索引、锁竞争；面试官会沿着“怎么发现→怎么定位→怎么验证”追问 | `backend_buzz`（规模/选型/故障）、`metric_context`；`backend_buzz` 的故障追问 |
| [网易数据中台 Java 一面复盘](https://blog.csdn.net/weixin_34101914/article/details/164161915) | 项目开场就问方法论和架构取舍（CDC vs 定时批量、分层建模、元数据/质量/血缘）；“为什么这样选”比“用了什么”更容易被追问 | `backend_buzz` 的选型/替代方案追问；`causal_gap` |

## 新增的信号

### 1. `metric_context`（归入 `no_metric_baseline`）

触发：出现 QPS/TPS/P95/P99/延迟/吞吐/可用性等性能数字，但没有测试环境、机器配置、数据量、并发、统计窗口等条件。

为什么：同一个“QPS 5000”在 4 核 8G 压测和 64 核生产集群上含义完全不同；面试官会先问“在哪测的、数据量多大、平均还是 P99”。

### 2. `backend_buzz`（归入 `unsupported_claim`）

触发：写了“高并发/高可用/高性能/分布式/微服务/分库分表/限流/熔断/QPS/SLA”，或“Redis/Kafka/缓存/消息队列 + 解决/支撑/保证/提升”，但没有规模数字、选型理由、故障处理或监控证据。

为什么：这些是架构标签，不是个人贡献。面试官会从“规模→取舍→故障”三层追问；只写“用了 Redis”无法说明你理解缓存一致性、命中率、失效和降级。

### 3. `mastery`（归入 `unsupported_claim`）

触发：出现“精通/熟练掌握/熟练使用/深入了解”，但没有项目、竞赛、论文、专利、证书、GitHub、上线部署等证据。

为什么：STAR 资料直接把“精通 xxx”列为高频翻车场景；面试官会用现场手写、边界场景、踩坑经历来验证。没有证据的“熟练”会被降级成“只会调 API”。

### 4. `strong_claim`（归入 `unsupported_claim`）

触发：出现“显著/大幅/明显 + 提升/提高/降低/增长/改善/优化”，但整句没有数字。

为什么：“显著提升”不是结果，是形容词。面试官第一问就是“提升了多少、怎么衡量、和谁比”。

### 5. `role_inflation`（归入 `unclear_ownership`）

触发：出现“主导/独立负责/从 0 到 1/技术负责人/项目负责人”，但没有团队人数、预算、排期、评审、决策、上线灰度等边界证据。

为什么：北森和 WPS 都提到“把参与写成主导、把模块写成整个系统”是最常见的夸大形态；面试官会追问“哪些是你拍板的、团队几个人、换掉你会怎样”。

### 6. `signals` 字段

每条风险现在带 `signals: string[]`，例如：

```json
["metric:数字无基线", "ownership:负责无边界"]
```

它让报告能解释“为什么这句话被标记”，而不是只给一个类型。`signals` 也会显示在 Web 卡片的展开区。

## 没有做的事

- 没有用这些资料训练模型，也没有把面经当成“标准答案”。
- 没有判断候选人是否真的做过；规则只能发现“表述缺少可追问的证据”。
- 没有覆盖所有岗位：后端信号最完整，前端/算法/产品只复用通用五类。
- 没有声称准确率；误报和漏报仍然存在，尤其是句子级规则会把上下文切开。

## 参考链接

- [JavaGuide：后端项目面试怎么讲？从项目介绍到技术难点和故障复盘](https://javaguide.cn/interview-preparation/backend-project-interview-guide.html)
- [北森：候选人夸大项目经历怎么办？AI 面试如何验证真实参与度](https://www.beisen.com/res/3561.html)
- [WPS：AI 写简历准吗：会编造什么、怎么检查](https://www.wps.cn/article/ai-write-resume-accuracy-check-edit-guide.html)
- [STAR 面试话术与模拟面试（GitHub）](https://github.com/bcefghj/learn-nanobot/blob/main/docs/16-star-interview-script/README.md)
- [阿里云开发者社区：面试官：你的项目有哪些难点？](https://developer.aliyun.com/article/1576468)
- [CSDN：网易数据中台 Java 一面复盘](https://blog.csdn.net/weixin_34101914/article/details/164161915)
